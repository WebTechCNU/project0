//@ts-check
const DEFAULT_TEXT = "New TODO"
const classNames = {
    TODO_ITEM: 'todo-container',
    TODO_CHECKBOX: 'todo-checkbox',
    TODO_TEXT: 'todo-text',
    TODO_DELETE: 'todo-delete',
}

const listSpan = /** @type {HTMLInputElement} */ (document.getElementById('todo-list'))
const itemCountSpan = /** @type {HTMLInputElement} */ (document.getElementById('item-count'))
const uncheckedCountSpan = /** @type {HTMLInputElement} */ (document.getElementById('unchecked-count'))

let itemCount = 0;
let uncheckedCount = 0;

/**
 * @typedef {{checked: boolean; text: string}} todo
 */

/** @type {Object.<number, todo>} */
const todos = {};

function newTodo() {
    const newTodoElement = createTodo();
    listSpan.appendChild(newTodoElement);
    updateItemCount();
    updateUncheckCount()
}


/**
 * @returns {HTMLElement}
 */
function createTodo() {
    let id = Object.keys(todos).length == 0 ? 1 : Math.max(...Object.keys(todos).map(e => Number.parseInt(e))) + 1;
    todos[id] = {
        checked: false, text: DEFAULT_TEXT
    }

    uncheckedCount++;
    itemCount++;

    const newElement = document.createElement("li")
    newElement.className = `${classNames.TODO_ITEM} ${classNames.TODO_ITEM}-${id}`
    newElement.appendChild(createCheckbox(id, false));
    newElement.appendChild(createTextInput(id, DEFAULT_TEXT));
    newElement.appendChild(createDeleteButton(id));
    
    return newElement;
}

/**
 * @param {Number} id 
 * @param {boolean} checked
 * @returns {HTMLElement}
 */
function createCheckbox(id, checked) {
    let newElement = document.createElement("input")
    newElement.type = "checkbox";
    newElement.checked = checked;
    newElement.className = `${classNames.TODO_CHECKBOX} ${classNames.TODO_CHECKBOX}-${id}`;
    newElement.onclick = () => {
        if (newElement.checked) uncheckedCount--;
        else uncheckedCount++;

        todos[id].checked = newElement.checked;
        updateUncheckCount();
    }

    return newElement
}

/**
 * @param {Number} id 
 * @param {String} text
 * @returns {HTMLElement}
 */
function createTextInput(id, text) {
    let newElement = document.createElement("input");
    newElement.value = text;
    newElement.className = `${classNames.TODO_TEXT} ${classNames.TODO_TEXT}-${id}`;
    newElement.onchange = () => {
        todos[id].text = newElement.value;
    }
    return newElement;
}

/**
 * @param {Number} id 
 * @returns {HTMLElement}
 */
function createDeleteButton(id) {
    let newElement = document.createElement("button");
    newElement.innerText = "x";
    newElement.className = `${classNames.TODO_DELETE} ${classNames.TODO_DELETE}-${id}`
    newElement.onclick = () => removeTodo(id);

    return newElement;
}

/**
 * @param {Number} id 
 */
function removeTodo(id) {
    listSpan.removeChild(document.getElementsByClassName(`${classNames.TODO_ITEM}-${id}`)[0])
    if (!todos[id].checked) uncheckedCount--;
    itemCount--;
    delete todos[id];

    updateUncheckCount()
    updateItemCount();
}

function updateUncheckCount() {
    uncheckedCountSpan.innerText = `${uncheckedCount}`
}

function updateItemCount() {
    itemCountSpan.innerText = `${itemCount}`;
}
